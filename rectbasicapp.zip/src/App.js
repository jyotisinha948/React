import Header from "./component/Header/Header";
import Banner from "./component/Banner/Banner";
import Card from "./component/Card/Card";
import Footer from "./component/Footer/Footer";
import logo from './logo.svg';
import './App.css';
function App() {
   const data=[
    {
    id:1,
    name:"HTML",
    contect:"HTML is the standard markup language for Web pages. With HTML you can create your own Website. HTML is easy to learn - You will enjoy it!"
  },
  {
    id:2,
    name:"CSS",
    contect:"CSS is the language we use to style an HTML document.CSS describes how HTML elements should be displayed.This tutorial will teach you CSS from basic to advanced."
  },
  {
    id:3,
    name:"JAVASCRIPT",
    contect:"JavaScript is the world's most popular programming language.JavaScript is the programming language of the Web.JavaScript is easy to learn."
  }
]





  return(
    <>
  <Header/>
  <Banner />
  <div className="card-container row">
    {
      data?data.map(data=>{
        return <Card N={data.name} C={data.contect}/>
      }):"no data to show" 
    }
  </div>
  </>
  );
  //CON?TV:FV;
  <Footer/>
}

export default App;

