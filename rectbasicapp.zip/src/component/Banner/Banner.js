import img from '../image/img.jpg';
import './Banner.css';
const banner=()=>{
    return(
        <div>
            <img src={img}/>
        </div>
    )
}
export default banner;