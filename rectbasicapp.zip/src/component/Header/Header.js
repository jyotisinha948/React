import './Header.css';
const header=()=>{
    return <header>
    <ul>
    <li>Home</li>
    <li>About</li>
    <li>Service</li>
    </ul>
    </header> 
}
export default header;