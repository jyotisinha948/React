import "./Card.css";
const card=(prop)=>{
    return(
    
        <div className="card col-sm-3">
            <h1>{prop.N}</h1>
            <p>{prop.C}</p>
        </div>
        
    );
}
export default card;     